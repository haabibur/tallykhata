# Tally Khata App

A simple tally application built with React.